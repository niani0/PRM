package com.example.mp3test.data

object DataSource {
    var email: String = ""
    var loggedInUser : UserEntity? = null
    var setWithoutDuplicates = HashSet<String>()
}